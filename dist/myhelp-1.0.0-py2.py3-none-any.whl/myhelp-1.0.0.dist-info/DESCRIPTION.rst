myhelp
======

A command line utility to create your own help. Written in python. You can find the link to source at https://github.com/tnkteja/myhelp.git . And distributions available in pypi at https://pypi.python.org/pypi/myhelp/1.0.0



